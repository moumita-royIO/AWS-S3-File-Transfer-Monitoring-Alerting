# Lambda for weekly file summary (scheduled)

import boto3
from datetime import datetime, timedelta
from helper import send_email, is_file_too_small

s3 = boto3.client("s3")
BUCKET = "prod"
LOCATIONS = ["Location1/", "Location2/"]

def lambda_handler(event, context):
    """
    Triggered weekly via EventBridge.
    Scans all files uploaded in the last 7 days and sends email
    if any file is smaller than 100 KB.
    """
    cutoff = datetime.utcnow() - timedelta(days=7)
    small_files = []

    for location in LOCATIONS:
        response = s3.list_objects_v2(Bucket=BUCKET, Prefix=location)
        if "Contents" not in response:
            print(f"No files in {location}")
            continue

        for obj in response["Contents"]:
            key = obj["Key"]
            size = obj["Size"]
            last_modified = obj["LastModified"]

            # Only consider files modified in the last week
            if last_modified >= cutoff:
                if is_file_too_small(size):
                    small_files.append(f"{key} - {size} bytes ({last_modified})")
                else:
                    print(f"File OK: {key} ({size} bytes)")

    if small_files:
        subject = f"Weekly S3 Small File Alert - {datetime.utcnow().strftime('%Y-%m-%d')}"
        body = "The following files are smaller than 100 KB in the past week:\n\n" + "\n".join(small_files)
        send_email(subject, body)
        print("Weekly summary email sent for small files.")
    else:
        print("All files are above minimum size in the last week.")
